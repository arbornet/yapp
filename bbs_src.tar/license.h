int get_license();
void release_license();
void  read_config();
char *get_conf_param PROTO((char *name, char *def));
void free_config();
int get_hits_today();
