/* HELP.H: @(#)help.h 1.1 93/04/22 Copyright (c)1993 thalerd */

int help PROTO((int argc, char **argv));
