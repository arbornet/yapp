/* DATES.H: @(#)dates.h 1.5 93/06/07 Copyright (c)1993 thalerd */
#include <sys/types.h>
char *do_getdate PROTO((time_t *tt,char *str));
