/* CHANGE.H: @(#)change.h 1.3 93/04/22 Copyright (c)1993 thalerd */
int display PROTO((int argc, char **argv));
int change PROTO((int argc, char **argv));
#define CF_PUBLIC 6 /* 1st N+1 files of cfiles[] are ok for sep %Ng */
