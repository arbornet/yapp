void custom_log PROTO((char *event, int type));
int logevent PROTO((int argc, char **argv));
