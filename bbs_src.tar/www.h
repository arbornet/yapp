int www_parse_post PROTO((int argc, char **argv));
int url_encode PROTO((int argc, char **argv));
void urlset PROTO(());
