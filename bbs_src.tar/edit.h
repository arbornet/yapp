int retitle PROTO((int argc, char **argv));
char *spaces PROTO((int n));
char *despace PROTO((char *str));
int modify PROTO((int argc, char **argv));
int dump_file PROTO((char *dir, char *filename, char **text, int mod));   
